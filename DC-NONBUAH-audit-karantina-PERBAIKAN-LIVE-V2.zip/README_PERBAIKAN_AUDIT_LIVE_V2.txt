DC NONBUAH - AUDIT LIVE V2

Perubahan:
1. Selisih Live sekarang memakai shell horizontal scroll yang benar-benar bisa digeser kiri/kanan di HP.
2. Header tabel diperjelas: No, QTY DB, QTY AUDIT, BARCODE · SALIN, Status, Revisi, Selisih, Nama Produk.
3. Kolom No/QTY DB/QTY AUDIT/Barcode tetap terlihat saat tabel digeser.
4. QTY AUDIT menampilkan status "Belum input" sampai benar-benar ada input fisik.
5. Tombol "View Sum" muncul setelah ada input fisik. Tombol membuka riwayat penambahan: +qty, waktu, nama user, kondisi, dan total akhir.
6. Filter "Sudah Input" sekarang hanya menghitung input fisik yang benar-benar tersimpan di auditList/server, bukan sekadar revisi.
7. Filter "Belum Input" tetap menunjukkan item yang belum mempunyai input fisik meskipun ada revisi.
8. Checkbox barcode "sudah disalin" tidak dianggap sebagai input fisik dan di-reset saat sesi Excel baru/clear.
9. Ditambahkan auditTargetVersion pada draft audit agar snapshot dari sesi/Excel lama tidak masuk kembali ke sesi baru.
10. Riwayat penambahan tetap mengikuti data server drafts/audit sehingga dapat terlihat setelah sinkronisasi realtime.

Firestore Rules yang dipakai tidak perlu diubah dari Rules baru yang sudah Anda publish, selama user sudah login:

rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if request.auth != null;
    }
  }
}
