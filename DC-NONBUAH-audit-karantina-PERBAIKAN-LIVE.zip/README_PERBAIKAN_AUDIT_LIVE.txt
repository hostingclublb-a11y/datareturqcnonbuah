DC NONBUAH - PERBAIKAN AUDIT LIVE

Perubahan utama:
1. Upload Excel Baru sekarang memulai sesi audit baru:
   - target Excel lama diganti
   - revisi/selisih lama di-reset
   - input fisik/qty audit lama di-reset
   - status salin barcode lokal di-reset
2. Target dan revisi disimpan di Firestore:
   auditLive/{auditLive_DC}/
   auditLive/{auditLive_DC}/revisions/{encoded-row-key}
3. Input audit fisik menggunakan Firestore transaction pada dokumen drafts/audit,
   sehingga dua HP dapat menambah qty bersamaan tanpa overwrite array secara
   last-write-wins.
4. Tabel audit bisa digeser kiri-kanan di HP. Kolom No, QTY DB, QTY AUDIT,
   dan BARCODE/SALIN tetap terlihat saat digeser.
5. Barcode memiliki tombol salin + checkbox penanda sudah disalin.
6. Revisi live tersinkron antar perangkat melalui listener Firestore.

PENTING - FIRESTORE RULES
Karena versi ini memakai collection baru "auditLive", Firestore Rules project
harus mengizinkan user yang berwenang membaca/menulis:
  /auditLive/{docId}
  /auditLive/{docId}/revisions/{revisionId}

Jangan mengganti seluruh rules project secara membabi buta. Tambahkan izin
tersebut ke rules yang sudah ada dan pertahankan pemeriksaan role/DC yang
digunakan aplikasi Anda.

Jika rules hanya mengizinkan user login, contoh dasar (sesuaikan dengan rules
role Anda) adalah:

match /auditLive/{docId} {
  allow read, write: if request.auth != null;
  match /revisions/{revisionId} {
    allow read, write: if request.auth != null;
  }
}

Setelah rules diperbarui, login ulang/refresh aplikasi dan pastikan badge
menunjukkan "☁ Server". Untuk pengujian realtime, buka audit yang sama di
dua HP, upload target dari satu HP, lalu input item dari kedua HP secara
bergantian/bersamaan. Keduanya harus menerima perubahan melalui listener.
